using HealthcareCRM.API.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthcareCRM.API.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<User> Users => Set<User>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");
                entity.HasIndex(u => u.Email).IsUnique();
            });
        }
    }
}
