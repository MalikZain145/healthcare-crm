-- =========================================================
-- User table -- used by HealthcareCRM.API (JWT Authentication)
-- =========================================================

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'User')
BEGIN
    CREATE TABLE [dbo].[User] (
        [Id]           INT IDENTITY(1,1)   NOT NULL,
        [FirstName]    NVARCHAR(100)       NOT NULL,
        [LastName]     NVARCHAR(100)       NOT NULL,
        [Email]        NVARCHAR(256)       NOT NULL,
        [PasswordHash] NVARCHAR(MAX)       NOT NULL,
        [Role]         NVARCHAR(20)        NOT NULL DEFAULT ('User'),
        [CreatedAt]    DATETIME2           NOT NULL DEFAULT (SYSUTCDATETIME()),
        [IsActive]     BIT                 NOT NULL DEFAULT (1),

        CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED ([Id] ASC)
    );

    -- Email must be unique -- used as the login identifier
    CREATE UNIQUE INDEX [IX_User_Email] ON [dbo].[User] ([Email]);
END
GO

-- Example seed (replace <pbkdf2-hash> with a real hash produced by
-- HealthcareCRM.API.Services.PasswordHasher.Hash before using in production)
-- INSERT INTO [dbo].[User] (FirstName, LastName, Email, PasswordHash, Role)
-- VALUES ('Admin', 'User', 'admin@medicare.com', '<pbkdf2-hash>', 'Admin');
