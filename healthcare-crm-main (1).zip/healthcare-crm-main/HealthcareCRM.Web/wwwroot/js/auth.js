// =========================================================
// auth.js
// Shared helpers for talking to HealthcareCRM.API's JWT
// authentication endpoints and guarding pages on the client.
//
// window.API_BASE_URL is set in Views/Shared/_Layout.cshtml
// from appsettings.json ("ApiSettings:BaseUrl").
// =========================================================

const AUTH_TOKEN_KEY = "hc_token";
const AUTH_USER_KEY = "hc_user";

function getApiBaseUrl() {
    return (window.API_BASE_URL || "https://localhost:7057/api").replace(/\/$/, "");
}

// ---- Token / user storage -------------------------------------------------

function saveSession(token, user) {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    if (user) {
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
    }
}

function getToken() {
    return localStorage.getItem(AUTH_TOKEN_KEY);
}

function getCurrentUser() {
    const raw = localStorage.getItem(AUTH_USER_KEY);
    return raw ? JSON.parse(raw) : null;
}

function isAuthenticated() {
    return !!getToken();
}

function clearSession() {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_USER_KEY);
}

// ---- Route protection -------------------------------------------------

// Call this at the top of any protected page.
// Redirects to /Account/Login (preserving the current URL) if no token exists.
function requireAuth() {
    if (!isAuthenticated()) {
        const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = `/Account/Login?returnUrl=${returnUrl}`;
    }
}

// Call this on Login/Register pages: if the user is already logged in,
// skip straight to the dashboard.
function redirectIfAuthenticated(target = "/PatientsMvc/Index") {
    if (isAuthenticated()) {
        window.location.href = target;
    }
}

// ---- API calls -------------------------------------------------

async function apiLogin(email, password) {
    const response = await fetch(`${getApiBaseUrl()}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    return { ok: response.ok, data };
}

async function apiRegister(firstName, lastName, email, password) {
    const response = await fetch(`${getApiBaseUrl()}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ firstName, lastName, email, password })
    });

    const data = await response.json();
    return { ok: response.ok, data };
}

// ---- Logout -------------------------------------------------

function logout() {
    clearSession();
    window.location.href = "/Account/Login";
}

// ---- Nav bar auth state -------------------------------------------------

// Toggles elements with [data-auth="in"] / [data-auth="out"]
// based on whether the user currently has a token.
function refreshAuthNav() {
    const loggedIn = isAuthenticated();
    document.querySelectorAll('[data-auth="in"]').forEach(el => {
        el.classList.toggle("d-none", !loggedIn);
    });
    document.querySelectorAll('[data-auth="out"]').forEach(el => {
        el.classList.toggle("d-none", loggedIn);
    });

    const user = getCurrentUser();
    const nameEl = document.getElementById("navUserName");
    if (nameEl && user) {
        nameEl.textContent = `${user.firstName} ${user.lastName}`.trim();
    }
}

document.addEventListener("DOMContentLoaded", refreshAuthNav);
