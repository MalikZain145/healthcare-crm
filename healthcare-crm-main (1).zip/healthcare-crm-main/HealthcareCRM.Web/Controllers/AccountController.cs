using Microsoft.AspNetCore.Mvc;

namespace HealthcareCRM.Web.Controllers
{
    /// <summary>
    /// Serves the Login and Register Razor views.
    /// Actual authentication happens client-side: the views call
    /// HealthcareCRM.API's /api/auth/login and /api/auth/register
    /// endpoints via fetch() and store the returned JWT in localStorage.
    /// </summary>
    public class AccountController : Controller
    {
        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        // GET: /Account/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // GET: /Account/Logout
        // Clears the client-side token (handled by auth.js) then
        // redirects back to the login page.
        [HttpGet]
        public IActionResult Logout()
        {
            return RedirectToAction(nameof(Login));
        }
    }
}
